//
//  EmployeeEntity+CoreDataClass.swift
//  CRUD ApplicationTask
//
//  Created by patururamesh on 06/11/24.
//
//

import Foundation
import CoreData

@objc(EmployeeEntity)
public class EmployeeEntity: NSManagedObject {

}
