//
//  carModel.swift
//  CarProject
//
//  Created by patururamesh on 24/07/24.
//

import Foundation

struct Car {
    let name: String
    let model: String
    let price: String
    let imageName: String
}
