//
//  CarCollectionViewController.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//
import UIKit

class CarCollectionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!

    var images = ["Car1","Car2","Car3"]
    var cars: [Car] = [
        Car(name: "Name: Benz", model: "Model: B", price: "price: $4,80,000", imageName: "Car1"),
        Car(name: "Name: Audi", model: "Model: A", price: "price: $8,40,000", imageName: "Car2"),
        Car(name: "Name: Mahindra",model: "Model: M", price: "price: $10,80,000", imageName: "Car3"),
        Car(name: "Name: BMW", model: "Model: B", price: "price: $12,40,000", imageName: "Car4"),
        Car(name: "Name: Swift", model: "Model: S", price: "price: $14,80,000", imageName: "Car5"),
        Car(name: "Name: Breeza", model: "Model: B", price: "price: $16,40,000", imageName: "Car6"),
        Car(name: "Name: Innova", model: "Model: I", price: "price: $8,80,000", imageName: "Car7"),
    ]
   
    var specifications = ["Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system"]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Car Collection"
        tableView.delegate = self
        tableView.dataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CarCollectionTableViewCell else {
            return UITableViewCell()
        }
        let car = cars[indexPath.row]
        cell.carNameLabel.text = car.name
        cell.carModelLabel.text = car.model
        cell.carPriceLabel.text = car.price
        cell.carImageView.image = UIImage(named: car.imageName)

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
       // let vc = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
      //  vc?.labelText = specifications[indexPath.row]
      
        //self.navigationController?.pushViewController(vc!, animated: true)
    }
}


