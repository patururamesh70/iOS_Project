//
//  LoginViewController.swift
//  CarProject
//
//  Created by patururamesh on 26/07/24.
//
import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var usernameErrorLabel: UILabel!
    @IBOutlet weak var passwordErrorLabel: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    
    // UserName and Password credentials
    private let validUsername = "Rameshchowdary"
    private let validPassword = "123456"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        usernameTextField.delegate = self
        passwordTextField.delegate = self
    }
    @IBAction func handleLogin() {
        let enteredUsername = usernameTextField.text ?? ""
        let enteredPassword = passwordTextField.text ?? ""
        
        var isValid = true
        
        if enteredUsername.isEmpty {
            usernameErrorLabel.text = "Username cannot be empty"
            usernameErrorLabel.textColor = .red
            usernameErrorLabel.isHidden = false
            isValid = false
        } else {
            usernameErrorLabel.isHidden = true
        }
        
        if enteredPassword.isEmpty {
            passwordErrorLabel.text = "Password cannot be empty"
            passwordErrorLabel.textColor = .red
            passwordErrorLabel.isHidden = false
            isValid = false
        } else {
            passwordErrorLabel.isHidden = true
        }
        
        if isValid {
            if enteredUsername == validUsername && enteredPassword == validPassword {
                print("Login successful")
                let LogVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeScrrenViewController") as! HomeScrrenViewController
                // present(LogVC, animated: true)
                self.navigationController?.pushViewController(LogVC, animated: true)
            } else {
                usernameErrorLabel.text = "Invalid username or password"
                usernameErrorLabel.isHidden = false
                usernameErrorLabel.textColor = .red
                passwordErrorLabel.text = "Invalid username or password"
                passwordErrorLabel.isHidden = false
                passwordErrorLabel.textColor = .red
            }
        }
    }
}
