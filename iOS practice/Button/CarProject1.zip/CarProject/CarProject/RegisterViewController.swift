//
//  RegisterViewController.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//


import UIKit

class RegisterViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var  nameTextField: UITextField!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameTextField.delegate = self
        usernameTextField.delegate = self
        emailTextField.delegate = self
        passwordTextField.delegate = self
        confirmPasswordTextField.delegate = self
        
    }
    
    @IBAction func handleSignUp() {
        let name = nameTextField.text ?? ""
        let username = usernameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        let confirmPassword = confirmPasswordTextField.text ?? ""
        
        var errorMessage = ""
        
        if name.isEmpty {
            errorMessage += "Name cannot be empty\n"
        }
        
        if username.isEmpty {
            errorMessage += "Username cannot be empty\n"
        }
        
        if email.isEmpty {
            errorMessage += "Email cannot be empty\n"
        } 
//        else if !isValidEmail(email) {
//            errorMessage += "Invalid email format\n"
//        }
        
        if password.isEmpty {
            errorMessage += "Password cannot be empty\n"
        } else if password.count < 6 {
            errorMessage += "Password must be at least 6 characters\n"
        }
        
        if confirmPassword.isEmpty {
            errorMessage += "Confirm Password cannot be empty\n"
        } else if password != confirmPassword {
            errorMessage += "Passwords do not match\n"
        }
        
        if errorMessage.isEmpty {
            print("Registration successful")
            let LogVC = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            present(LogVC, animated: true)
            //self.navigationController?.pushViewController(LogVC, animated: true)
        } else {
            errorLabel.text = errorMessage
            errorLabel.textColor = .red
            errorLabel.isHidden = false
        }
    }
    
//    private func isValidEmail(_ email: String) -> Bool {
//        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
//        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
//        return emailPred.evaluate(with: email)
//    }
    
    
}
