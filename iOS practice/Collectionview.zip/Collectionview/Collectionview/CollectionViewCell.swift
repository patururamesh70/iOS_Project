//
//  CollectionViewCell.swift
//  Collectionview
//
//  Created by patururamesh on 19/07/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var label: UILabel!
}
