//
//  ViewcontrollerCollectionViewCell.swift
//  collectionview3
//
//  Created by patururamesh on 27/07/24.
//

import UIKit

class ViewcontrollerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageview: UIImageView!
}
