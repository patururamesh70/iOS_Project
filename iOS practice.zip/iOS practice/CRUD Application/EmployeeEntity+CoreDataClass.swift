//
//  EmployeeEntity+CoreDataClass.swift
//  CRUD Application
//
//  Created by patururamesh on 07/11/24.
//
//

import Foundation
import CoreData

@objc(EmployeeEntity)
public class EmployeeEntity: NSManagedObject {

}
