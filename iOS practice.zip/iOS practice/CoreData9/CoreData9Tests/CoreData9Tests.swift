//
//  CoreData9Tests.swift
//  CoreData9Tests
//
//  Created by patururamesh on 23/09/24.
//

import Testing
@testable import CoreData9

struct CoreData9Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
