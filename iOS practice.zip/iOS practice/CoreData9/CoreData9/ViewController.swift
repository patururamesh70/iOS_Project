//
//  ViewController.swift
//  CoreData9
//
//  Created by patururamesh on 23/09/24.
//

import UIKit

class ViewController: UIViewController {
    
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
      

}

