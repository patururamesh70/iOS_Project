//
//  Bus+CoreDataClass.swift
//  CoreData9
//
//  Created by patururamesh on 23/09/24.
//
//

import Foundation
import CoreData

@objc(Bus)
public class Bus: NSManagedObject {

}
