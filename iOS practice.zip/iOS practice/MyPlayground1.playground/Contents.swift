import UIKit

var a = 5
var b = 10


a = a + b
b = a - b


print("a =",a)
print("b =",b)

