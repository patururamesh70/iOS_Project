//
//  Car+CoreDataClass.swift
//  CoreData5
//
//  Created by patururamesh on 20/09/24.
//
//

import Foundation
import CoreData

@objc(Car)
public class Car: NSManagedObject {

}
