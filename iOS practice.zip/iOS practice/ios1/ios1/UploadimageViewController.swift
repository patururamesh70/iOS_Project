//
//  UploadimageViewController.swift
//  ios1
//
//  Created by patururamesh on 22/11/24.
//

import UIKit

class UploadimageViewController: UIViewController {
 
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
