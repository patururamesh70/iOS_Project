//
//  ViewController.swift
//  ios1
//
//  Created by patururamesh on 22/11/24.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    // Create an instance of CLLocationManager
    let locationManager = CLLocationManager()
    let geocoder = CLGeocoder()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the location manager
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Request location permissions
        locationManager.requestWhenInUseAuthorization()
        
        // Check if location services are enabled
        if CLLocationManager.locationServicesEnabled() {
            // Start updating the location
            locationManager.startUpdatingLocation()
        } else {
            print("Location services are disabled.")
        }
    }
    
    // MARK: - CLLocationManagerDelegate Methods
    
    // Called when the location is updated
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
        let latitude = location.coordinate.latitude
        let longitude = location.coordinate.longitude
        print("Latitude: \(latitude), Longitude: \(longitude)")
        
        // Perform reverse geocoding
        reverseGeocode(location: location)
        
        // Stop updates if you don't need continuous tracking
        locationManager.stopUpdatingLocation()
    }
    
    // Called if an error occurs
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to get location: \(error.localizedDescription)")
    }
    
    // MARK: - Reverse Geocoding
    func reverseGeocode(location: CLLocation) {
        geocoder.reverseGeocodeLocation(location) { placemarks, error in
            if let error = error {
                print("Reverse geocoding failed: \(error.localizedDescription)")
                return
            }
            
            if let placemark = placemarks?.first {
                // Format and display address information
                let address = """
                \(placemark.name ?? "Unknown"), \
                \(placemark.locality ?? "Unknown"), \
                \(placemark.administrativeArea ?? "Unknown"), \
                \(placemark.country ?? "Unknown")
                """
                print("Address: \(address)")
            }
        }
    }
}
