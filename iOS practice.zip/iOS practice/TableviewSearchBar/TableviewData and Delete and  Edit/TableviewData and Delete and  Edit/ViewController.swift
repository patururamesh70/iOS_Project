//
//  ViewController.swift
//  TableviewData and Delete and  Edit
//
//  Created by patururamesh on 20/07/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

