//
//  ViewController.swift
//  Auri
//
//  Created by patururamesh on 25/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

