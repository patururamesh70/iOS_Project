//
//  AuriTests.swift
//  AuriTests
//
//  Created by patururamesh on 25/10/24.
//

import Testing
@testable import Auri

struct AuriTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
