//
//  Car+CoreDataClass.swift
//  CoreData2
//
//  Created by patururamesh on 16/09/24.
//
//

import Foundation
import CoreData

@objc(Car)
public class Car: NSManagedObject {

}
