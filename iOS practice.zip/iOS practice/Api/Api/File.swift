//
//  File.swift
//  Api
//
//  Created by patururamesh on 18/10/24.
//


https://jsonplaceholder.typicode.com/posts