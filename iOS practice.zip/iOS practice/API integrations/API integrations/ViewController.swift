//
//  ViewController.swift
//  API integrations
//
//  Created by patururamesh on 06/11/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

