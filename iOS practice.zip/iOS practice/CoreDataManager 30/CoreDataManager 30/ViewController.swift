//
//  ViewController.swift
//  CoreDataManager 30
//
//  Created by patururamesh on 08/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

