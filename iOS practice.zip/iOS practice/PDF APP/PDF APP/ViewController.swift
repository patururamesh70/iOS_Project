//
//  ViewController.swift
//  PDF APP
//
//  Created by patururamesh on 10/12/24.
//

import UIKit
import PDFKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupButton()
    }

    private func setupButton() {
        // Create a button
        let openPDFButton = UIButton(type: .system)
        openPDFButton.setTitle("Open PDF", for: .normal)
        openPDFButton.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        openPDFButton.frame = CGRect(x: 0, y: 0, width: 200, height: 50)
        openPDFButton.center = view.center
        openPDFButton.addTarget(self, action: #selector(openPDF), for: .touchUpInside)
        
        // Add the button to the view
        view.addSubview(openPDFButton)
    }

    @objc private func openPDF() {
        // Create a PDFViewController
        let pdfVC = PDFViewController()
        
        // Load a PDF file from the app bundle
        if let pdfURL = Bundle.main.url(forResource: "Patururamesh resume", withExtension: "pdf") {
            pdfVC.loadPDF(from: pdfURL)
            
            // Check if navigation controller exists
            if let navigationController = navigationController {
                navigationController.pushViewController(pdfVC, animated: true)
            } else {
                // Present modally if no navigation controller
                pdfVC.modalPresentationStyle = .fullScreen
                present(pdfVC, animated: true, completion: nil)
            }
        } else {
            print("PDF file not found.")
        }
    }
}

// Separate PDFViewController to display the PDF
class PDFViewController: UIViewController {
    private let pdfView = PDFView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupPDFView()
    }

    private func setupPDFView() {
        // Configure the PDFView
        pdfView.frame = view.bounds
        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        pdfView.autoScales = true // Automatically adjust zoom scale
        view.addSubview(pdfView)
    }

    func loadPDF(from url: URL) {
        // Load and display the PDF document
        if let pdfDocument = PDFDocument(url: url) {
            pdfView.document = pdfDocument
        } else {
            print("Failed to load PDF document.")
        }
    }
}


//import UIKit
//import PDFKit
//
//class ViewController: UIViewController {
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        setupPDFView()
//    }
//    
//    private func setupPDFView() {
//        // Create a PDFView
//        let pdfView = PDFView(frame: view.bounds)
//        pdfView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
//        pdfView.autoScales = true // Automatically scale the PDF to fit the view
//        view.addSubview(pdfView)
//        
//        // Load a PDF file from the app bundle
//        if let pdfURL = Bundle.main.url(forResource: "Patururamesh resume", withExtension: "pdf") {
//            pdfView.document = PDFDocument(url: pdfURL)
//        } else {
//            print("Failed to load PDF file.")
//        }
//    }
//}
//
//
