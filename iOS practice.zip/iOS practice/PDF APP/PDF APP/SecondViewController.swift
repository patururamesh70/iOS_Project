//
//  SecondViewController.swift
//  PDF APP
//
//  Created by patururamesh on 10/12/24.
//


import UIKit

// MARK: - ViewController
class SecondViewController: UIViewController {
    @IBOutlet weak var tableView = UITableView()
    private var pokemonList: [Pokemon] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchPokemonData()
    }
    private func fetchPokemonData() {
        guard let url = URL(string: "https://pokeapi.co/api/v2/pokemon/?offset=0&limit=1000") else { return }

        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let data = data {
                do {
                    let decodedResponse = try JSONDecoder().decode(PokemonResponse.self, from: data)
                    DispatchQueue.main.async {
                        self?.pokemonList = decodedResponse.results
                        self?.tableView?.reloadData()
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            } else if let error = error {
                print("Network error: \(error.localizedDescription)")
            }
        }.resume()
    }
}

// MARK: - UITableViewDataSource and UITableViewDelegate
extension SecondViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemonList.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PokemonCell", for: indexPath)
        let pokemon = pokemonList[indexPath.row]
        cell.textLabel?.text = pokemon.url.capitalized
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let pokemon = pokemonList[indexPath.row]
        print("Selected Pokémon: \(pokemon.url)")
    }
}
