//
//  Model.swift
//  PDF APP
//
//  Created by patururamesh on 10/12/24.
//

import Foundation

// MARK: - Model
struct PokemonResponse: Decodable {
    let results: [Pokemon]
}

struct Pokemon: Decodable {
    let name: String
    let url: String
}
