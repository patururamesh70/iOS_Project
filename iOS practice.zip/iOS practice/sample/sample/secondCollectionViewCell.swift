//
//  secondCollectionViewCell.swift
//  sample
//
//  Created by patururamesh on 06/08/24.
//

import UIKit

class secondCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageview: UIImageView!
}
