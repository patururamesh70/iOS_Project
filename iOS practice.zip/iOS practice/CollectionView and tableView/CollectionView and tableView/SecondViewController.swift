//
//  SecondViewController.swift
//  CollectionView and tableView
//
//  Created by patururamesh on 25/11/24.
//

import UIKit

class SecondViewController: UIViewController {
    let data = 5
    let data1 = 6
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
}
