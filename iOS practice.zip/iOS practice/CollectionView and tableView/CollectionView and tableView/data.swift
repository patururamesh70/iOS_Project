//
//  data.swift
//  CollectionView and tableView
//
//  Created by patururamesh on 19/07/24.
//

import Foundation

struct MovieData {
    let  sectionType: String
    let  Movies: [String]
}
