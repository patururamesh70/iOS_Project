//
//  CollectionViewCell.swift
//  CollectionView and tableView
//
//  Created by patururamesh on 19/07/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageview : UIImageView!
}
