//
//  Student+CoreDataClass.swift
//  CoreData3
//
//  Created by patururamesh on 17/09/24.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
