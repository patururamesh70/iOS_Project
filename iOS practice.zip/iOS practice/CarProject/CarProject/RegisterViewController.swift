//
//  RegisterViewController.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//

import UIKit

class RegisterViewController : UIViewController,UITextFieldDelegate{
    
    @IBOutlet weak var nametextfield: UITextField!
    @IBOutlet weak var emailtextfield: UITextField!
    @IBOutlet weak var passwordtextfield: UITextField!
    @IBOutlet weak var conformtextfield: UITextField!
    @IBOutlet weak var SignUpButtontextfield: UIButton!
    @IBOutlet weak var nameErrorLabel: UILabel!
    @IBOutlet weak var emailErrorLabel: UILabel!
    @IBOutlet weak var passwordErrorLabel: UILabel!
    @IBOutlet weak var conformErrorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Welcome To Registration Page"
        self.navigationItem.backButtonDisplayMode = .minimal
    }
    @IBAction func SignUPButton(_ sender: Any) {
        var isValid = true
        
        if nametextfield.text!.count >= 5 {
            nameErrorLabel.isHidden = true
            print("username is Valid")
        }else{
            nameErrorLabel.text = "Username must be at least 6 characters long"
            nameErrorLabel.textColor = .red
            nameErrorLabel.isHidden = false
            print("Username is invalid")
            isValid = false
        }
        
        if isValidEmail(emailtextfield.text!){
            emailErrorLabel.isHidden = true
            print("please Enter Your valid Email")
        }else{
            emailErrorLabel.text = "please Enter Valid Email Adress"
            emailErrorLabel.textColor = .red
            emailErrorLabel.isHidden = false
            print("Invalid EmailId")
            isValid = false
        }
        
        if isValidPassword(passwordtextfield.text!) {
            passwordErrorLabel.isHidden = true
            print("Password is valid")
        } else {
            passwordErrorLabel.text = "Password must be at least 6 digits long"
            passwordErrorLabel.textColor = .red
            passwordErrorLabel.isHidden = false
            print("Password is invalid")
            isValid = false
        }
        
        if passwordtextfield.text == conformtextfield.text{
            conformErrorLabel.isHidden = true
            print("password match")
        }else{
            conformErrorLabel.text = "password do not match"
            conformErrorLabel.textColor = .red
            conformErrorLabel.isHidden = false
            print("password donot match")
            isValid = false
        }
        
        if isValid{
            
            UserDefaults.standard.setValue(nametextfield.text, forKey: "username")
            UserDefaults.standard.setValue(passwordtextfield.text, forKey: "password")
            UserDefaults.standard.setValue(emailtextfield.text, forKey: "email")
            
            let storyboard = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
            self.navigationController?.pushViewController(storyboard, animated: true)
        }
    }
    func isValidPassword(_ password: String) -> Bool {
        let numberRegex = "^[0-9]{6,}$"
        return NSPredicate(format: "SELF MATCHES %@", numberRegex).evaluate(with: password)
    }
    func isValidEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
        }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == passwordtextfield || textField == conformtextfield{
            
            if nametextfield.text!.count <= 5 {
                nameErrorLabel.text = "Username must be at least 5 characters long"
                nameErrorLabel.isHidden = false
                return false
            }else{
                nameErrorLabel.isHidden = true
            }
    }
        return true
    }

}
