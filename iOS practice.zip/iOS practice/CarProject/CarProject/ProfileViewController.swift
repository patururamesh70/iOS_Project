//
//  ProfileViewController.swift
//  CarProject
//
//  Created by patururamesh on 07/08/24.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var imageview : UIImageView!
    @IBOutlet weak var UsernameLabel: UILabel!
    @IBOutlet weak var EmailLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "profile"
        
        let username = UserDefaults.standard.string(forKey:"username")
        UsernameLabel.text = username
        
        let email = UserDefaults.standard.string(forKey: "email")
        EmailLabel.text = email
    }
    


}
