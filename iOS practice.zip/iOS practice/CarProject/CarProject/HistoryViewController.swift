//
//  HistoryViewController.swift
//  CarProject
//
//  Created by patururamesh on 01/08/24.
//

import UIKit

class HistoryViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "History"
       
    }
    


}
