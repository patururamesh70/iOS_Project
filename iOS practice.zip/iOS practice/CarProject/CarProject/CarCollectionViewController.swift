//
//  CarCollectionViewController.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//
import UIKit

class CarCollectionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!

    
    var cars: [Car] = [
        Car(name: "Benz", model: "B", price: "$4,80,000", imageName: "Car1"),
        Car(name: "Audi", model: "A", price: "$8,40,000", imageName: "Car2"),
        Car(name: "Mahindra",model: "M", price: "$10,80,000", imageName: "Car3"),
        Car(name: "BMW", model: "B", price: "$12,40,000", imageName: "Car4"),
        Car(name: "Swift", model: "S", price: "$14,80,000", imageName: "Car5"),
        Car(name: "Breeza", model: "Model: B", price: "Price: $16,40,000", imageName: "Car6"),
        Car(name: "Innova", model: "I", price: "$8,80,000", imageName: "Car7"),
    ]
    var images = [
            ["Car1", "Car2", "Car4", "Car3"],
            ["Car2", "Car1", "Car3", "Car4"],
            ["Car3", "Car4", "Car1", "Car2"],
            ["Car4", "Car2", "Car6", "Car7"],
            ["Car5", "Car6", "Car7", "Car6"],
            ["Car6", "Car7", "Car3", "Car3"],
            ["Car7", "Car2", "Car3", "Car2"]]
           
    var specifications = ["Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7.Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system","Features: 1.Driver assistance features, 2.Navigation system 3.Advanced safety features 4.Connectivity  5.Automatic climate control 6.Infotainment system, 7. Adaptive headlights 8.Smart key technology, 9.Premium sound system"]
    
    var properties = [(name: "Benz", model: "B", price: "$4,80,000"),(name: "Audi", model: "A", price: "$8,40,000"), (name: "Mahindra",model: "M", price: "$10,80,000"),(name: "BMW", model:  "B", price: "$12,40,000"),
        (name: "Swift", model: "S", price: "$14,80,000"),(name: "Breeza", model: "B", price: " $16,40,000"),(name: "Innova", model: "I", price:"$8,80,000")]

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.backButtonDisplayMode = .minimal
        self.title = "Car Collection"
        tableView.delegate = self
        tableView.dataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CarCollectionTableViewCell else {
            return UITableViewCell()
        }
        let car = cars[indexPath.row]
        cell.carNameLabel.text = car.name
        cell.carModelLabel.text = car.model
       // cell.carPriceLabel.text = car.price
        cell.carPriceLabel.text = car.price
        
        cell.carImageView.image = UIImage(named: car.imageName)

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController
        vc?.labelText = specifications[indexPath.row]
        vc?.imageNames = images[indexPath.row]
        vc?.LabelText1 = properties[indexPath.row]
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}

