//
//  TabBarViewController.swift
//  CarProject
//
//  Created by patururamesh on 05/08/24.
//

import UIKit

class TabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.backButtonDisplayMode = .minimal
       
    }
    
}
