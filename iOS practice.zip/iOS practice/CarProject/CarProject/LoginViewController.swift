//
//  LoginViewController.swift
//  CarProject
//
//  Created by patururamesh on 24/07/24.
//

import UIKit

class LoginViewController : UIViewController,UITextFieldDelegate{
    
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    @IBOutlet weak var usernameErrorLabel: UILabel!
    @IBOutlet weak var passwordErrorLabel: UILabel!
    @IBOutlet weak var LoginButton:UIButton!
    
    var username : String!
    var password : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        username = UserDefaults.standard.string(forKey: "username")
        password = UserDefaults.standard.string(forKey: "password")
        
        self.title = "welcome to Login Page"
        self.navigationItem.backButtonDisplayMode = .minimal
    }
    
    @IBAction func LoginButton(_ sender: Any) {
        
        var isValid = true
    
        if userNameTextfield.text == username{
            usernameErrorLabel.isHidden = true
            print("Valid Username")
        } else if userNameTextfield.text!.count >= 5 && userNameTextfield.text != username{
            usernameErrorLabel.text = "Username is invalid"
            usernameErrorLabel.isHidden = false
            isValid = false
        } else{
            usernameErrorLabel.text = "username must be 5 character"
            usernameErrorLabel.textColor = .red
            usernameErrorLabel.isHidden = false
            print("invalid username")
            isValid = false
        }
        
        if isValidPassword(passwordTextfield.text!) || passwordTextfield.text == password {
            passwordErrorLabel.isHidden = true
            print("Valid Password")
        }else if passwordTextfield.text!.count >= 8 && passwordTextfield.text != password{
            passwordErrorLabel.text = "password is invalid"
            passwordErrorLabel.isHidden = false
            isValid = false
        }else{
            passwordErrorLabel.text = "password must be 8 digits along"
            passwordErrorLabel.textColor = .red
            passwordErrorLabel.isHidden = false
            print("invalid password")
            isValid = false
        }
        
        if isValid{
            UserDefaults.standard.set(true, forKey: "isLogin")
             let storyboard = self.storyboard?.instantiateViewController(identifier: "TabBarViewController") as! TabBarViewController
                self.navigationController?.pushViewController(storyboard, animated: true)
        }
        
        func isValidPassword(_ password: String) -> Bool {
            let numberRegex = "^[0-9]{8,}$"
            return NSPredicate(format: "SELF MATCHES %@", numberRegex).evaluate(with: password)
        }
        
        func isValidEmail(_ email: String) -> Bool {
            let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
            return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
            
        }
        func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
            if textField == passwordTextfield{
                
                if userNameTextfield.text!.count < 5{
                    usernameErrorLabel.text = "Username must be at least 5 characters long"
                    usernameErrorLabel.textColor = .red
                    usernameErrorLabel.isHidden = false
                    return false
                } else {
                    usernameErrorLabel.isHidden = true
                }
            }
            return true
        }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            
            return true
        }
        
    }
}
