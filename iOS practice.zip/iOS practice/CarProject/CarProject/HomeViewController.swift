//
//  HomeViewController.swift
//  CarProject
//
//  Created by patururamesh on 24/07/24.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var Button1: UIButton!
    @IBOutlet weak var Button: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Welcometo Garage"
        self.navigationController?.isNavigationBarHidden = false
        
        self.navigationItem.backButtonDisplayMode = .minimal
        

        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .orange
        self.navigationController?.navigationBar.standardAppearance = appearance
        self.navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }
    @IBAction func clickOnBtn2(){
        let CarVC = self.storyboard?.instantiateViewController(withIdentifier: "CarCollectionViewController") as! CarCollectionViewController
        self.navigationController?.pushViewController(CarVC, animated: true)
        
        
    }
}
