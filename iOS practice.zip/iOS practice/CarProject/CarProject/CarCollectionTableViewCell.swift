//
//  CarCollectionTableViewCell.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//

import UIKit

class CarCollectionTableViewCell: UITableViewCell {

    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var carPriceLabel: UILabel!
    @IBOutlet weak var carModelLabel: UILabel!
    @IBOutlet weak var Lable3: UILabel!
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var carNameLabel: UILabel!
    @IBOutlet weak var carImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}


