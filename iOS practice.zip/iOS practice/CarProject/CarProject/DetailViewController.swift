//
//  DetailViewController.swift
//  CarProject
//
//  Created by patururamesh on 25/07/24.
//

import UIKit

class DetailViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    @IBOutlet weak var Specificationlabel: UILabel!
    @IBOutlet weak var Label1: UILabel!
    @IBOutlet weak var Label2: UILabel!
    @IBOutlet weak var Label3: UILabel!
    @IBOutlet weak var NameLabel1: UILabel!
    @IBOutlet weak var ModelLabel2: UILabel!
    @IBOutlet weak var PriceLabel3: UILabel!
    private var collectionView: UICollectionView!
    private let images = [UIImage(named: "Car1"), UIImage(named: "Car2"), UIImage(named: "Car3"), UIImage(named: "Car4")]
    var imageName: String?
    var labelText: String?
    var LabelText1: (name: String, model: String, price: String)?
    var imageNames: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Set up labels
        if let labelText = labelText {
            Specificationlabel.text = labelText
        }
        if let LabelText1 = LabelText1 {
            NameLabel1.text = LabelText1.name
            ModelLabel2.text = LabelText1.model
            PriceLabel3.text = LabelText1.price
        }
        
        self.navigationItem.backButtonDisplayMode = .minimal
        self.title = "Detail ViewController"

        // Create and configure the collection view
        setupCollectionView()

        // Manage logout button visibility
        updateLogoutButton()
    }

    private func setupCollectionView() {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 5

        let collectionViewFrame = CGRect(x: 30, y: 130, width: 300, height: 200)
        collectionView = UICollectionView(frame: collectionViewFrame, collectionViewLayout: layout)
        collectionView.backgroundColor = .white
        collectionView.showsHorizontalScrollIndicator = false

        collectionView.register(ImageCollectionViewCell.self, forCellWithReuseIdentifier: "ImageCell")
        collectionView.dataSource = self
        collectionView.delegate = self

        view.addSubview(collectionView)
    }

    private func updateLogoutButton() {
        let isLogin = UserDefaults.standard.bool(forKey: "isLogin")
        if isLogin {
            let logoutButton = UIBarButtonItem(title: "LogOut", style: .plain, target: self, action: #selector(logoutButtonTapped))
            self.navigationItem.rightBarButtonItem = logoutButton
        } else {
            self.navigationItem.rightBarButtonItem = nil
        }
    }

    @objc private func logoutButtonTapped() {
        UserDefaults.standard.set(false, forKey: "isLogin")
        self.navigationController?.popToRootViewController(animated: true)
    }

    // MARK: UICollectionViewDataSource

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as! ImageCollectionViewCell
        cell.imageView.image = UIImage(named: imageNames[indexPath.item])
        return cell
    }

    // MARK: UICollectionViewDelegateFlowLayout

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellWidth = collectionView.frame.size.width / 2 - 15
        let cellHeight = collectionView.frame.size.height - 20
        return CGSize(width: cellWidth, height: cellHeight)
    }
//
//    // MARK: UIScrollViewDelegate
//    
//    func scrollViewDidScroll(_ scrollView: UIScrollView) {
//        let pageIndex = round(scrollView.contentOffset.x / collectionView.frame.width)
//        pageviewcontroller.currentPage = Int(pageIndex)
//    }

    @IBAction func clickOnBtn1() {
        let isLogin = UserDefaults.standard.bool(forKey: "isLogin")
        if isLogin {
            let alert = UIAlertController(title: "Alert", message: "My Team will be Updated", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        } else {
            let LogVC = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
            self.navigationController?.pushViewController(LogVC, animated: true)
        }
    }
}

// Custom UICollectionViewCell for images
class ImageCollectionViewCell: UICollectionViewCell {
    let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleToFill
        imageView.clipsToBounds = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.cornerRadius = 15
        return imageView
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(imageView)

        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            imageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
