//
//  ViewController.swift
//  CarProject
//
//  Created by patururamesh on 24/07/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var Fristtimebutton: UIButton!
    @IBOutlet weak var AlawaysRegisterbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    self.navigationItem.backButtonDisplayMode = .minimal
    }
    
    @IBAction func clickOnBtn(){
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
    @IBAction func clickOnBtn1(){
        let LogVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(LogVC, animated: true)
    }
}

