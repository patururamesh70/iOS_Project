//
//  HomeViewController.swift
//  Singletons
//
//  Created by patururamesh on 27/11/24.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let user = User.currentUser
        nameLabel.text = user.username
        passwordLabel.text = user.password
    }


}
