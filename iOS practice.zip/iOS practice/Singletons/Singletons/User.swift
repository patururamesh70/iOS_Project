//
//  User.swift
//  Singletons
//
//  Created by patururamesh on 27/11/24.
//

import Foundation

class User {
    var username: String = "UserInfo"
    var password: String = "PasswordInfo"
    
    static let currentUser: User = User()
    private init() { }
    
}
