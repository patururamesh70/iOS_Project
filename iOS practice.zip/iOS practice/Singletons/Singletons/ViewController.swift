//
//  ViewController.swift
//  Singletons
//
//  Created by patururamesh on 27/11/24.
//  create a rameshchowdary

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func saveUserAndMoveHome(){
        
        let username = userNameTF.text ?? ""
        let password = passwordTF.text ?? ""
        
        let user = User.currentUser
        user.username = username
        user.password = password
        
        let homeViewController = storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
        navigationController?.pushViewController(homeViewController, animated: true)
    }


}

