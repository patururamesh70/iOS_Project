//
//  DogImageResponse.swift
//  Web Api
//
//  Created by patururamesh on 13/08/24.
//

import Foundation

struct DogImageResponse: Codable {
    let message: [String]
    let status: String
}
