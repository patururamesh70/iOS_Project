//
//  ViewController.swift
//  example
//
//  Created by patururamesh on 19/08/24.
//

import UIKit

class ViewController: UIViewController {
    
    var a = 5
    var b = 10
    override func viewDidLoad() {
        super.viewDidLoad()
        print(a)
        print(b)
        
        var a = a + b
        var b = a - b
        
    }
}
