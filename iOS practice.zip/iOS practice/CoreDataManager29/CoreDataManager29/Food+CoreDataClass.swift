//
//  Food+CoreDataClass.swift
//  CoreDataManager29
//
//  Created by patururamesh on 08/10/24.
//
//

import Foundation
import CoreData

@objc(Food)
public class Food: NSManagedObject {

}
