//
//  ViewController.swift
//  Gusters
//
//  Created by patururamesh on 28/11/24.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imageview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(doubleTapped))
        doubleTapGesture.numberOfTapsRequired = 2
        imageview?.addGestureRecognizer(doubleTapGesture)
    }
  
    @objc func doubleTapped(){
        print("doubleTapGesture")
    }
    
    @IBAction func imageTapped(_ sender: Any) {
        print("TapGesture")
    }
    @IBAction func pinchTapped(_ sender: Any) {
        print("pinchTapped")
        print(sender)
        if let pinch = sender as? UIPinchGestureRecognizer {
            print(pinch.numberOfTouches)
            print(pinch.location(in: pinch.view))
            print(pinch.view)
            print(pinch.location(ofTouch: 1, in: pinch.view))
            print(pinch.location(ofTouch: 0, in: pinch.view))
        }
    }
    @IBAction func LongPress(_ sender: Any) {
        print("LongPressGesture")
    }
    @IBAction func ScreenEdgePan(_ sender: Any) {
        print("ScreenEdgePanGesture")
    }
    @IBAction func Pan(_ sender: Any) {
        print("PanGesture")
    }
    @IBAction func Swipe(_ sender: Any) {
        print("SwipeGesture")
    }
    @IBAction func Rotation(_ sender: Any) {
        print("RotationGesture")
    }
}

