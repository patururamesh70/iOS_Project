//
//  model.swift
//  Gusters
//
//  Created by patururamesh on 28/11/24.
//

import Foundation

struct model: Codable {
    
}
