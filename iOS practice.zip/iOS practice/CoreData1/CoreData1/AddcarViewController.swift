//
//  AddcarViewController.swift
//  CoreData1
//
//  Created by patururamesh on 16/09/24.
//

import UIKit
import CoreData

class AddcarViewController: UIViewController {
    
    @IBOutlet weak var BrandTF: UITextField!
    @IBOutlet weak var colorTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    @IBAction func Save(){
        let brand: String = BrandTF.text!
        let color: String = colorTF.text!
        
        guard let car = NSManagedObject(entity: Car.entity(), insertInto: CoreDataManger.shared.context) as? Car else { return
          }
            car.brand = brand
            car.color = color
           CoreDataManger.shared.saveContext()
    }
    @IBAction func Clear(){
        
        BrandTF.text = ""
        colorTF.text = ""
        
    }
}
