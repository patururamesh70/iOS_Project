//
//  ViewController.swift
//  CoreData1
//
//  Created by patururamesh on 16/09/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var CarsListView: UITableView!
    var cars : [Car] = []
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
    override func viewWillAppear(_ animated: Bool) {
        Readcars()
    }
    
    func Readcars() {
        cars = CoreDataManger.shared.fetch()
        print(cars)
        CarsListView.reloadData()
        
    }
}
extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cars.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") else { return UITableViewCell() }
        
        cell.textLabel?.text = cars[indexPath.row].brand
        cell.detailTextLabel?.text = cars[indexPath.row].color
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let aCar = cars[indexPath.row]
        aCar.brand = "UPDated Brand"
        CoreDataManger.shared.saveContext()
        Readcars()
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        let car = cars[indexPath.row]
        CoreDataManger.shared.delete(car: car)
        Readcars()
    }
    
}

