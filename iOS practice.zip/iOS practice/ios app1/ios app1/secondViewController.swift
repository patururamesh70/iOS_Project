//
//  secondViewController.swift
//  ios app1
//
//  Created by patururamesh on 04/12/24.
//

import UIKit
import AVFoundation

class secondViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // Button action to launch the camera
    @IBAction func openCamera(_ sender: UIButton) {
        // Check if camera is available on the device
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePickerController = UIImagePickerController()
            imagePickerController.delegate = self
            imagePickerController.sourceType = .photoLibrary // Set the source to the camera
            imagePickerController.allowsEditing = false // Allow or disallow editing of the photo
            
            // Present the image picker controller
            present(imagePickerController, animated: true, completion: nil)
        } else {
            print("Camera is not available.")
        }
    }
    
    // Delegate method to handle the image after capture
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // Get the captured image
        if let image = info[.originalImage] as? UIImage {
            // Do something with the image, e.g., display it
            print("Captured Image: \(image)")
            
            // You can also display it in an imageView
            // imageView.image = image
        }
        
        // Dismiss the image picker
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Delegate method to handle cancellation
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // Dismiss the image picker
        picker.dismiss(animated: true, completion: nil)
    }
}
