//
//  model.swift
//  ios app1
//
//  Created by patururamesh on 04/12/24.
//

import Foundation

class model1: Codable {
    var message: String
    var status: String
    
}
