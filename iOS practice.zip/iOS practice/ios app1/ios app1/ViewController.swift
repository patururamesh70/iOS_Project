//
//  ViewController.swift
//  ios app1
//
//  Created by patururamesh on 01/12/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        // Create the URL object
        if let url = URL(string: "https://jsonplaceholder.typicode.com/posts") {
            
            // Create a URLRequest object
            var request = URLRequest(url: url)
            request.httpMethod = "POST" // Specify POST method
            
            // Define the data to send in the body of the POST request
            let postData = [
                "title": "New Post Title",
                "body": "This is the content of the post.",
                "userId": 1
            ] as [String : Any]
            
            do {
                // Convert the dictionary into JSON data
                let jsonData = try JSONSerialization.data(withJSONObject: postData, options: [])
                
                // Set the request body
                request.httpBody = jsonData
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                // Create a data task to send the request
                let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                    // Handle errors
                    if let error = error {
                        print("Error: \(error.localizedDescription)")
                        return
                    }
                    
                    // Check if data exists and if the response is valid
                    if let data = data {
                        do {
                            // Decode the response if necessary (e.g., if the server returns the created resource)
                            if let postResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                                print("Response: \(postResponse)")
                            }
                        } catch {
                            print("Error decoding response: \(error.localizedDescription)")
                        }
                    }
                }
                
                // Start the data task
                task.resume()
                
            } catch {
                print("Error creating JSON data: \(error.localizedDescription)")
            }
        }

        
    }


}

