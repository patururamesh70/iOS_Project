//
//  Model.swift
//  Api Integration_json
//
//  Created by patururamesh on 21/11/24.
//

import Foundation

struct ToDo: Decodable {
    let localized_name: String
    let img: String
}
