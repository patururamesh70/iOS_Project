//
//  SecondViewController.swift
//  PagingView
//
//  Created by patururamesh on 23/07/24.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
