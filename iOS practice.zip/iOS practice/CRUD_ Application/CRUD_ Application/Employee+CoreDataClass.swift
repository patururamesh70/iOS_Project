//
//  Employee+CoreDataClass.swift
//  CRUD_ Application
//
//  Created by patururamesh on 07/11/24.
//
//

import Foundation
import CoreData

@objc(Employee)
public class Employee: NSManagedObject {

}
