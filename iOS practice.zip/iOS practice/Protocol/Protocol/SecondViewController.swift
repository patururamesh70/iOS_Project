//
//  SecondViewController.swift
//  Protocol
//
//  Created by patururamesh on 29/11/24.
//

import UIKit

protocol DataBack {
    func passData(data1: String, data2:String, data3:String, data4:String)
}

class SecondViewController: UIViewController {

    @IBOutlet weak var textfield2: UITextField!
    @IBOutlet weak var textfield1: UITextField!
    @IBOutlet weak var textfield3: UITextField!
    @IBOutlet weak var textfield4: UITextField!
    
    var delegate:DataBack!
    override func viewDidLoad() {
        super.viewDidLoad()
         
    
    }
    @IBAction func clickOnBack() {
        delegate.passData(data1: textfield1.text!, data2: textfield2.text!, data3: textfield3.text!, data4: textfield4.text!)
        navigationController?.popViewController(animated: true)
    }
    
}
