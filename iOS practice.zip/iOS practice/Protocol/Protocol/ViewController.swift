//
//  ViewController.swift
//  Protocol
//
//  Created by patururamesh on 29/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Button: UIButton!
    @IBOutlet weak var textfield: UITextField!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickMove() {
        let v1 = (storyboard?.instantiateViewController(identifier: "SecondViewController") as? SecondViewController)!
        v1.delegate = self
        navigationController?.pushViewController(v1, animated: true)
    }
}
extension ViewController: DataBack {
    func passData(data1: String, data2: String, data3: String, data4: String) {
        label1.text = data1
        label2.text = data2
        label3.text = data3
        textfield.text = data4
    }
    
    
}
